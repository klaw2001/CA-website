import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";

const Newsletter = () => {
  return (
    <>
      <section className="newsletter-section">
        <Container fluid className="px-0 py-5 m-0">
          <Row className="background p-0 text-center text-white d-flex justify-content-center align-items-center">
            <h2 className="py-4">GET IN TOUCH</h2>
            <Col>
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15068.861338003615!2d72.8521856!3d19.2294449!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b0d42c95bdf9%3A0x5a3374a957943f4b!2sTryCatch%20Classes%20%7C%20Full%20Stack%20Web%20Development%20%7C%20Data%20Science%20Python%20Alteryx%20%7C%20Software%20Testing%20%7C%20Android%20IOS%20Flutter%20Training!5e0!3m2!1sen!2sin!4v1696954147734!5m2!1sen!2sin"
                width="600"
                height="450"
                // style="border:0;"
                allowfullscreen=""
                loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"
              ></iframe>
            </Col>
            <Col xs={12} md={6}>
              <Form>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Control
                    type="name"
                    placeholder="Name"
                    className="rounded-0"
                  />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Control
                    type="email"
                    placeholder="Email"
                    className="rounded-0"
                  />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Control
                    type="contact"
                    placeholder="Contact"
                    className="rounded-0"
                  />
                </Form.Group>
                <Form.Group
                  className="mb-3 "
                  controlId="exampleForm.ControlTextarea1"
                >
                  <Form.Control
                    as="textarea"
                    rows={3}
                    placeholder="Your Message"
                    className="rounded-0"
                  />
                </Form.Group>
                <Button
                  className="app-btn text-white"
                  type="submit"
                  style={{ width: "120px" }}
                >
                  Submit
                </Button>
              </Form>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default Newsletter;
