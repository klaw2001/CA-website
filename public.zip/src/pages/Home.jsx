import React from "react";
import MyCarousel from "../sections/CarouselSections/MyCarousel";
import AboutUs from "../sections/AboutSection/Aboutus";
import Services from "../sections/ServiceSection/Ourservices";
import Testimonial from "../sections/TestimonialSection/Testimonial";
import Newsletter from "../sections/NewsletterSection/Newsletter";
import Footercomp from "../sections/Footersection/Footercomp";
import Footerbottom from "../sections/Footersection/Footerbottom";
const Home = () => {
  return (
    <>
      <MyCarousel />
      <AboutUs/>
      <Services/>
      <Testimonial/>
      <Newsletter/>
     <Footercomp/>
     <Footerbottom/>
    </>
  );
};

export default Home;
