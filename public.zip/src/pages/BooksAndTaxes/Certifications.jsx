import React from 'react'

const Certifications = () => {
  return (
    <div>Certifications</div>
  )
}

export default Certifications