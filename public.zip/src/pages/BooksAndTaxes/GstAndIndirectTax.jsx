import React from 'react'

const GstAndIndirectTax = () => {
  return (
    <div>GstAndIndirectTax</div>
  )
}

export default GstAndIndirectTax