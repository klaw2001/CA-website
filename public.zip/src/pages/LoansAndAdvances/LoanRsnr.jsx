import React from 'react'

const LoanRsnr = () => {
  return (
    <div>LoanRsnr</div>
  )
}

export default LoanRsnr