import React from 'react'

const DocumentAndLicense = () => {
  return (
    <div>DocumentAndLicense</div>
  )
}

export default DocumentAndLicense