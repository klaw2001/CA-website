import React from 'react'

const OnePersonCompany = () => {
  return (
    <div>OnePersonCompany</div>
  )
}

export default OnePersonCompany