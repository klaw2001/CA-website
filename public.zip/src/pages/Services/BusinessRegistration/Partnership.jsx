import React from 'react'

const Partnership = () => {
  return (
    <div>Partnership</div>
  )
}

export default Partnership