import React from 'react'

const NgoRegistration = () => {
  return (
    <div>NgoRegistration</div>
  )
}

export default NgoRegistration