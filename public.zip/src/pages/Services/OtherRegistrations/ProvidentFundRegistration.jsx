import React from 'react'

const ProvidentFundRegistration = () => {
  return (
    <div>ProvidentFundRegistration</div>
  )
}

export default ProvidentFundRegistration