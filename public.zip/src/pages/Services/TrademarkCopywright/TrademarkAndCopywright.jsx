import React from 'react'

const TrademarkAndCopywright = () => {
  return (
    <div>TrademarkAndCopywright</div>
  )
}

export default TrademarkAndCopywright